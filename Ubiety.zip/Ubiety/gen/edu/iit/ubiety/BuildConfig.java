/** Automatically generated file. DO NOT MODIFY */
package edu.iit.ubiety;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}